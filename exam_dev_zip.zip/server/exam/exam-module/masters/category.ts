'use server';

import { api, getSearchParamsUrl } from '@/lib/apiService';
import type { ApiSearchparams } from '@/types';
import type { IMasterCategory } from '@/types/exam/exam-module/masters';

export async function getExamMasterCategory(searchParams?: ApiSearchparams) {
    const urlParams = getSearchParamsUrl(searchParams ?? {});
    const url = `/exam_master_category/30?${urlParams}`;
    return await api.get<IMasterCategory>('exam', url);
}

export async function addOrUpdateExamMasterCategory(data: any) {
    const url = '/exam_master_category';
    return await api.post<any>('exam', url, data);
}

export async function toggleMasterExamCategory(mi_id: number, id: number) {
    const url = `/exam_master_category/toggle_exam_master_category/${mi_id}/${id}`;
    return await api.put('exam', url);
}
