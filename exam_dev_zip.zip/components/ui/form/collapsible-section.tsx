import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronRight } from 'lucide-react';
import { type ReactNode, useEffect, useState } from 'react';

interface CollapsibleSectionProps {
    title?: string;
    description?: string;
    children: ReactNode;
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    className?: string;
    headerClassName?: string;
    contentClassName?: string;
    variant?: 'default' | 'ghost' | 'outline';
    size?: 'sm' | 'md' | 'lg';
    keepContentMounted?: boolean;
}

export function CollapsibleSection({
    title,
    description,
    children,
    defaultOpen = false,
    onOpenChange,
    className = '',
    headerClassName = '',
    contentClassName = '',
    variant = 'default',
    size = 'md',
    keepContentMounted = true
}: CollapsibleSectionProps) {
    const [isOpen, setIsOpen] = useState(defaultOpen);
    const [hasBeenOpened, setHasBeenOpened] = useState(defaultOpen);

    useEffect(() => {
        if (isOpen && !hasBeenOpened) {
            setHasBeenOpened(true);
        }
    }, [isOpen, hasBeenOpened]);

    const handleOpenChange = (open: boolean) => {
        setIsOpen(open);
        onOpenChange?.(open);
    };

    const sizeClasses = {
        sm: 'text-sm',
        md: 'text-base',
        lg: 'text-lg'
    };

    const variantClasses = {
        default: 'border shadow-sm',
        ghost: 'border-0 shadow-none',
        outline: 'border-2 shadow-none'
    };

    // Compact header when no title/description
    const compactHeader = !title && !description ? 'py-2' : 'py-4';

    return (
        <Collapsible open={isOpen} onOpenChange={handleOpenChange} className={className}>
            <Card className={`${variantClasses[variant]} transition-all duration-200 ${className}`}>
                <CollapsibleTrigger asChild>
                    <CardHeader
                        className={`flex cursor-pointer flex-row items-center justify-between transition-colors duration-200 hover:bg-muted/50 ${compactHeader} ${headerClassName}
                        `}>
                        {(title || description) && (
                            <div className='space-y-1'>
                                {title && <h3 className={`font-semibold tracking-tight ${sizeClasses[size]}`}>{title}</h3>}
                                {description && <p className='text-muted-foreground text-sm'>{description}</p>}
                            </div>
                        )}
                        <Button variant='ghost' size='sm' className='ml-auto h-8 w-8 p-0'>
                            <ChevronRight
                                className={`h-4 w-4 transform transition-transform duration-200 ${isOpen ? 'rotate-90' : 'rotate-0'}`}
                            />
                        </Button>
                    </CardHeader>
                </CollapsibleTrigger>

                {(keepContentMounted ? hasBeenOpened : isOpen) && (
                    <CollapsibleContent
                        className='transition-all duration-200 data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down'
                        style={keepContentMounted && !isOpen ? { display: 'none' } : undefined}>
                        <CardContent className={`pt-0 ${contentClassName}`}>{children}</CardContent>
                    </CollapsibleContent>
                )}
            </Card>
        </Collapsible>
    );
}
