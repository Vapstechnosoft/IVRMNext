'use client';

import { type VariantProps, cva } from 'class-variance-authority';
import {
    FieldError as AriaFieldError,
    type FieldErrorProps as AriaFieldErrorProps,
    Group as AriaGroup,
    type GroupProps as AriaGroupProps,
    Label as AriaLabel,
    type LabelProps as AriaLabelProps,
    Text as AriaText,
    type TextProps as AriaTextProps,
    composeRenderProps
} from 'react-aria-components';

import { cn } from '@/lib/utils';

const labelVariants = cva([
    ' text-sm font-normal leading-none',
    /* Disabled */
    'data-[disabled]:cursor-not-allowed data-[disabled]:opacity-70',
    /* Invalid */
    'group-data-[invalid]:text-destructive'
]);

const Label = ({ className, ...props }: AriaLabelProps) => <AriaLabel className={cn(labelVariants(), className)} {...props} />;

function FormDescription({ className, ...props }: AriaTextProps) {
    return <AriaText className={cn('text-[0.8rem] text-muted-foreground', className)} {...props} slot='description' />;
}

function FormError({ className, children }: { className?: string; children: React.ReactNode }) {
    return <div className={cn('font-medium text-[0.8rem] text-destructive', className)}>{children}</div>;
}

function FieldError({ className, ...props }: AriaFieldErrorProps) {
    return <AriaFieldError className={cn('font-medium text-[0.8rem] text-destructive', className)} {...props} />;
}

const fieldGroupVariants = cva('', {
    variants: {
        variant: {
            default: [
                'relative flex h-9 w-full items-center overflow-hidden rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors',
                /* Focus Within */
                'data-[focus-within]:outline-none data-[focus-within]:ring-1 data-[focus-within]:ring-ring',
                /* Disabled */
                'data-[disabled]:opacity-50'
            ],
            ghost: ''
        }
    },
    defaultVariants: {
        variant: 'default'
    }
});

interface GroupProps extends AriaGroupProps, VariantProps<typeof fieldGroupVariants> {}

function FieldGroup({ className, variant, ...props }: GroupProps) {
    return (
        <AriaGroup className={composeRenderProps(className, (className) => cn(fieldGroupVariants({ variant }), className))} {...props} />
    );
}

export { Label, labelVariants, FieldGroup, fieldGroupVariants, FieldError, FormDescription, FormError };
